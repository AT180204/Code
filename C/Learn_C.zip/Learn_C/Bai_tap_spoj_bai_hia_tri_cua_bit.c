#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int x,n;
    scanf("%d%d",&x,&n);

    printf("%d",(x>>n)&1);
    return 0;
}
