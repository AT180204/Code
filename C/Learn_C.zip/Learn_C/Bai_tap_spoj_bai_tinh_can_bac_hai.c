#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
    double x;
    scanf("%lf",&x);

    if (x<0)
        printf("%d",-1);
    else
        printf("%.10lf", sqrt(x));

    return 0;
}




