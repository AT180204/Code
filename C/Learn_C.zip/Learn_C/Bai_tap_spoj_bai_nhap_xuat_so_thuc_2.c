#include <stdio.h>

int main()
{
    double a;
    int d1,d2;

    scanf("%lf", &a);
    scanf("%d%d", &d1, &d2);

    printf("a = %*.*lf", d1, d2, a);

    return 0;
}
