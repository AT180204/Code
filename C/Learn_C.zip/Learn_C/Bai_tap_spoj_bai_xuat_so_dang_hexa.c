#include <stdio.h>

int main()
{
    int a;

    scanf("%d", &a);

    printf("0x%.8x", a);

    return 0;
}
