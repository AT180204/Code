#include<stdio.h>
int main()
{
  int n,i;
  long S;
  S = 0;
  i = 1;
  printf("\nNhập vào số n: ");
  scanf("%d", &n);

  for(int i = 1; i <=n; i++)
    {
        S = S + i;
    }
  printf("\nTổng 1 + 2 + ... + %d là %ld: ", n, S);

  printf("\n----------------------------------------\n");
  printf("Chương trình này được đăng tại Freetuts.net");
}
