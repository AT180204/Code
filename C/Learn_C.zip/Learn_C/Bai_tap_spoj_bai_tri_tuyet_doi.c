#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
    int a,b,c;
    scanf("%d%d%d",&a,&b,&c);

    if (a<0)
        a=-a;
    else if (b<0)
        b=-b;
    else if (c<0)
        c=-c;

    printf("|a| = %d\n|b| = %d\n|c| = %d",a,b,c);
    return 0;
}
