#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    double a,b,c,d,e,f,x,y;
    scanf("%lf%lf%lf\n%lf%lf%lf",&a,&b,&e,&c,&e,&f);

    if

    return 0;
}
