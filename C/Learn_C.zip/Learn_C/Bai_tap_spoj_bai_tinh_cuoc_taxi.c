#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float s,fee=0;
    scanf("%f",&s);

    if (s > 0 && s <= 0.8)
    {
        fee = 10000;
    }
    else if (s > 0.8 && s <= 30)
    {
        fee = 10000 + (s-0.8)*11000;
    }
    else
    {
        fee = 10000 + 30*11000 + (s-30.8)*10000;
    }

    printf("%.0f",(round(fee/1000)*1000));
    return 0;
}
