#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float x;
    scanf("%f",&x);
    int a=(int)x;
    printf("%d",a);
    return 0;
}

