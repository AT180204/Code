#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int d,m,y,tt=0;
    scanf("%d%d%d",&d,&m,&y);

    if (1 < m)
        tt = tt + 31;
    if (2 < m)
    {
        if (y%400==0 || (y%4==0 && y%100!=0))
            tt = tt + 29;
        else
            tt = tt + 28;
    }
    if (3 < m)
        tt = tt + 31;
    if (4 < m)
        tt = tt + 30;
    if (5 < m)
        tt = tt + 31;
    if (6 < m)
        tt = tt + 30;
    if (7 < m)
        tt = tt + 31;
    if (8 < m)
        tt = tt + 31;
    if (9 < m)
        tt = tt + 30;
    if (10 < m)
        tt = tt + 31;
    if (11 < m)
        tt = tt + 30;

    printf("Ngay %d/%d la ngay thu %d cua nam %d",d,m,tt+d,y);
    return 0;
}




