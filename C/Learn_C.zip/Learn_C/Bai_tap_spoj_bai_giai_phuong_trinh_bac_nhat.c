#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
    double a,b;
    scanf("%lf%lf",&a,&b);

    if (a==0)
        if (b==0)
            printf("Moi x la nghiem");
        else
            printf("Vo nghiem");
    else
        printf("%.5lf", (-b/a));

    return 0;
}





