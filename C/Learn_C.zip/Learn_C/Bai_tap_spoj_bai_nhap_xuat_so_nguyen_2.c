#include <stdio.h>

int main()
{
    long long int a;
    int da;
    unsigned long long int b;
    int db;

    scanf("%lld%d", &a, &da);
    scanf("%llu%d", &b, &db);

    printf("a = %*lld\n", da, a);
    printf("b = %*llu\n", db, b);

    return 0;
}
