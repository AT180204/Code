#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float a,b,x;
    scanf("%f %f %f",&a,&b,&x);
    printf("Gia tri cua %f x %f + %f = %f",a,x,b,(a*x+b));

    return 0;
}

