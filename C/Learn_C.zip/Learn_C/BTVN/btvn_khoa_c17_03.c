#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    printf("DOI THOI GIAN TU GIAY SANG GIO + PHUT + GIAY\n\n");

    unsigned int t;

    //Nhap t

    printf("Nhap thoi gian: ");
    scanf("%u",&t);

    //Xu ly
    printf("%u giay = %u gio %u phut %u giay",t,(t/3600),(t%3600/60),(t%3600%60));
    return 0;
}
