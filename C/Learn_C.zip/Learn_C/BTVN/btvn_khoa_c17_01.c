#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int a,b;
    scanf("%d %d",&a,&b);
    printf("Chu vi hinh chu nhat canh %d, %d la: %d\n",a,b,((a+b)*2));
    printf("Dien tich hinh chu nhat canh %d, %d la: %d",a,b,(a*b));
    return 0;
}
