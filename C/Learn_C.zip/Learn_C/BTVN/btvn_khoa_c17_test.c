#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    printf("DOI THOI GIAN TU GIAY SANG GIO + PHUT + GIAY\n\n");

    int t;

    //Nhap t

    printf("Nhap thoi gian: ");
    scanf("%d",&t);

    //Xu ly
    printf("%d",t%4%2);
    return 0;
}

