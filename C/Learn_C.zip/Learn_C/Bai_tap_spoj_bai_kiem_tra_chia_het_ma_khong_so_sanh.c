#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
    int a,b;
    scanf("%d%d",&a,&b);

    if (!(a%b)) {
        printf("%c", '1');
    } else {
        printf("%c", '0');
    }

    return 0;
}
