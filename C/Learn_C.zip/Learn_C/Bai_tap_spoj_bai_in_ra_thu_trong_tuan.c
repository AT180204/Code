#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
    int a;
    scanf("%d",&a);

    if (a==2)
        printf("Thu Hai");
    else if (a==3)
        printf("Thu Ba");
    else if (a==4)
        printf("Thu Tu");
    else if (a==5)
        printf("Thu Nam");
    else if (a==6)
        printf("Thu Sau");
    else if (a==7)
        printf("Thu Bay");
    else if (a==8)
        printf("Chu Nhat");
    else
        printf("Khong hop le");
    return 0;
}



