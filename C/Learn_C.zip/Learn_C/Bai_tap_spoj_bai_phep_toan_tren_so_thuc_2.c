#include <stdio.h>

int main()
{
    double a, b;
    int d1,d2;

    scanf("%lf\n%lf\n%d%d", &a, &b, &d1, &d2);

    printf("( %*.*lf) + ( %*.*lf) = %*.*lf\n", d1, d2, a, d1, d2, b, d1, d2, a+b);
    printf("( %*.*lf) - ( %*.*lf) = %*.*lf\n", d1, d2, a, d1, d2, b, d1, d2, a-b);
    printf("( %*.*lf) * ( %*.*lf) = %*.*lf\n", d1, d2, a, d1, d2, b, d1, d2, a*b);
    printf("( %*.*lf) / ( %*.*lf) = %*.*lf\n", d1, d2, a, d1, d2, b, d1, d2, a/b);

    return 0;
}
