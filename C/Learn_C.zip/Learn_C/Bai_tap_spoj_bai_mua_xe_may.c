#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    unsigned int salary,tax,shp;
    int tienconlai;
    scanf("%u",&salary);

    //tien luong
    if (salary<10000000)
    {
        tax = salary*5/100;
        shp = tax*30/100;
        if (shp<3000000)
            shp = 3000000;
    }
    else
    {
        tax = salary/10;
        shp = tax*30/100;
    }
    //tien con lai
    tienconlai = salary-tax-shp;
    if (tienconlai<=0)
        printf("Khong the");
    else
    {
        if ((20000000%(salary-tax-shp))==0)
            printf("%u thang",(20000000/(salary-tax-shp)));
        else
            printf("%u thang",(20000000/(salary-tax-shp))+1);
    }
    return 0;
}
