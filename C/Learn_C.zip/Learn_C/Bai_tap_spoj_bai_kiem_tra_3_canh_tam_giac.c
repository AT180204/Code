#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float a,b,c,max;
    scanf("%f%f%f",&a,&b,&c);

    if (a>=b)
        if(a>=c)
        {
            max = a;
            if (max < b+c)
                printf("%.2f, %.2f, %.2f co the la 3 canh cua tam giac",a,b,c);
            else
                printf("%.2f, %.2f, %.2f khong the la 3 canh cua tam giac",a,b,c);
        }
        else
        {
            max = c;
            if (max < b+a)
                printf("%.2f, %.2f, %.2f co the la 3 canh cua tam giac",a,b,c);
            else
                printf("%.2f, %.2f, %.2f khong the la 3 canh cua tam giac",a,b,c);
        }
    else
        if (b>=c)
        {
            max = b;
            if (max < c+a)
                printf("%.2f, %.2f, %.2f co the la 3 canh cua tam giac",a,b,c);
            else
                printf("%.2f, %.2f, %.2f khong the la 3 canh cua tam giac",a,b,c);
        }
        else
        {
            max = c;
            if (max < b+a)
                printf("%.2f, %.2f, %.2f co the la 3 canh cua tam giac",a,b,c);
            else
                printf("%.2f, %.2f, %.2f khong the la 3 canh cua tam giac",a,b,c);
        }

    return 0;
}
