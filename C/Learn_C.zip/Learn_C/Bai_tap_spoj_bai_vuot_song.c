#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    unsigned int m,a,b,c,d;
    scanf("%u\n%u%u%u%u",&m,&a,&b,&c,&d);

    if ((a+b<=m || a+c<=m || a+d<=m || b+c<=m || b+d<=m || c+d<=m) && (m >= a) && (m >= b) && (m >= c) && (m >= d))
        printf("CO");
    else
        printf("KHONG");
    return 0;
}
