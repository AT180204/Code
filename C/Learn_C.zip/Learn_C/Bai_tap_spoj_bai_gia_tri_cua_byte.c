#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    unsigned int x;
    scanf("%u",&x);

    printf("x = %u = 0x%08X\n",x,x);
    printf("byte 0: 0x%02X = %u\n",(x<<24)>>24,(x<<24)>>24);
    printf("byte 1: 0x%02X = %u\n",((x<<16)>>24),((x<<16)>>24));
    printf("byte 2: 0x%02X = %u\n",((x<<8)>>24),((x<<8)>>24));
    printf("byte 3: 0x%02X = %u\n",(x>>24),(x>>24));

    return 0;
}
