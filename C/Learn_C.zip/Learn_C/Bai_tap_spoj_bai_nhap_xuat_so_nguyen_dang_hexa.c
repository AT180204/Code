#include <stdio.h>

int main()
{
    int a;

    scanf("%x", &a);

    printf("0x%x = %d", a, a);

    return 0;
}
