#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    unsigned int r,c;
    scanf("%u%u",&r,&c);

    if (r%2==0 && c%2==0)
        printf("%u",(((r/2)*(c/2))*50000+((r*c-(r/2)*(c/2))*10000)));
    else if (r%2==0 && c%2==1)
        printf("%u",(((r/2)*(c/2+1))*50000+((r*c-(r/2)*(c/2+1))*10000)));
    else if (r%2==1 && c%2==0)
        printf("%u",(((r/2+1)*(c/2))*50000+((r*c-(r/2+1)*(c/2))*10000)));
    else
        printf("%u",(((r/2+1)*(c/2+1))*50000+((r*c-(r/2+1)*(c/2+1))*10000)));
    return 0;
}
