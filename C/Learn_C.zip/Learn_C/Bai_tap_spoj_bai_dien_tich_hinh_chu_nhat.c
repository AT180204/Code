#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    double a, b;
    scanf("%lf %lf", &a, &b);

    printf("%15.5lf",a*b);
    return 0;
}
