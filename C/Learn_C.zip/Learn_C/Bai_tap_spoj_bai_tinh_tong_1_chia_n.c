#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    unsigned int n,i=1;
    scanf("%u",&n);
    double S = 0;

    for (i=1;i<=n;i++)
    {
        S = S + 1/i;
    }

    printf("%.10lf",S);
    return 0;
}
