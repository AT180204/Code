#include <stdio.h>

int main()
{
    float a;

    scanf("%f", &a);

    printf("%.5f", a);

    return 0;
}
