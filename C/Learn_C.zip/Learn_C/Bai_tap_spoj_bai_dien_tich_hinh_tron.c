#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    double r;
    scanf("%lf",&r);

    printf("%15.10lf",r*r*3.14);
    return 0;
}






