#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int d,m,y;
    scanf("%d%d%d",&d,&m,&y);

    if (m == 1 ||m == 3 ||m == 5 ||m == 7 ||m == 8 ||m == 10 ||m == 12 )
    {
        if (d > 0 && d <32)
        {
            printf("%d/%d/%d: hop le",d,m,y);
        }
        else
        {
            printf("%d/%d/%d: khong hop le",d,m,y);
        }
    }
    else if (m == 4 || m == 6 || m == 9 || m == 11)
    {
        if (d > 0 && d < 31)
        {
            printf("%d/%d/%d: hop le",d,m,y);
        }
        else
        {
            printf("%d/%d/%d: khong hop le",d,m,y);
        }
    }
    else if ( m == 2)
    {
        if (y%400==0 || y%4==0 && y%100!=0)
        {
            if (d > 0 && d < 30)
            {
                printf("%d/%d/%d: hop le",d,m,y);
            }
            else
            {
                printf("%d/%d/%d: khong hop le",d,m,y);
            }
        }
        else
        {
            if (d > 0 && d < 29)
            {
                printf("%d/%d/%d: hop le",d,m,y);
            }
            else
            {
                printf("%d/%d/%d: khong hop le",d,m,y);
            }
        }
    }
    else
        printf("%d/%d/%d: khong hop le",d,m,y);
    return 0;
}

