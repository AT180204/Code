#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
    double a,b;
    scanf("%lf\n%lf",&a,&b);

    if (a==b)
        printf("a = b");
    else if (a>b)
        printf("a > b");
    else
        printf("a < b");
    return 0;
}
