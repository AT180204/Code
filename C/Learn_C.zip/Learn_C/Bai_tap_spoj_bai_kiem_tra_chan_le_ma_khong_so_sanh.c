#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
    int  a;
    scanf("%d",&a);

    printf("%d", 1-(a%2));

    return 0;
}
