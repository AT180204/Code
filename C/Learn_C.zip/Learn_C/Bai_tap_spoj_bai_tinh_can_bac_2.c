#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    double x;
    scanf("%lf", &x);
    double can_x = sqrt(sqrt(x*x));
    printf("%.4lf", can_x);
    return 0;
}
