#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float a,b,c,max,canhgocvuong1,canhgocvuong2;
    scanf("%f%f%f",&a,&b,&c);

    if (a>=b)
        if(a>=c)
        {
            max = a;
            canhgocvuong1 = b;
            canhgocvuong2 = c;
        }
        else
        {
            max = c;
            canhgocvuong1 = b;
            canhgocvuong2 = a;
        }
    else
        if (b>c)
        {
            max = b;
            canhgocvuong1 = a;
            canhgocvuong2 = c;
        }
        else
        {
            max = c;
            canhgocvuong1 = b;
            canhgocvuong2 = a;
        }
    if (max*max == canhgocvuong1*canhgocvuong1 + canhgocvuong2*canhgocvuong2)
        printf("Co");
    else
        printf("Khong");

}
