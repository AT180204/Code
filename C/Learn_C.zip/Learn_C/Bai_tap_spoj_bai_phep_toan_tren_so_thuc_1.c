#include <stdio.h>

int main()
{
    float a, b;

    scanf("%f\n%f", &a, &b);

    printf("a   = %10.3f\n", a);
    printf("b   = %10.3f\n", b);
    printf("a+b = %10.3f\n", a+b);
    printf("a-b = %10.3f\n", a-b);
    printf("a*b = %10.3f\n", a*b);
    printf("a/b = %10.3f\n", a/b);

    return 0;
}
