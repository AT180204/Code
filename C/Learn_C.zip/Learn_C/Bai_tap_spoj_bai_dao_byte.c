#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    unsigned int a;
    scanf("%x",&a);

    printf("0x%08x ~ %10u\n",a,a);
    a = (a>>24)|((a>>8)&0xff00)|((a<<8)&0xff0000)|(a<<24);
    printf("0x%08x ~ %10u\n",a,a);

    return 0;
}
