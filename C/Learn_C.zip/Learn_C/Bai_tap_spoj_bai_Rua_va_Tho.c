#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    unsigned int t,chuky,st = 0;
    scanf("%u",&t);

    chuky = t/15;
    if ((t-chuky*15)<5)
        st = chuky*10 + (t-chuky*15)*2;
    else st = chuky*10 + 10;

    printf("Rua chay duoc %um\n",t);
    printf("Tho chay duoc %um\n",st);

    if (t>st)
        printf("Rua thang cuoc");
    else if (t == st)
        printf("Tho va rua hoa");
    else
        printf("Tho thang cuoc");
    return 0;
}
