#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float x,y;
    scanf("%f",&x);

    if (x >= 5)
    {
        y = 2*x*x+5*x+9;
    }
    else
    {
        y = -2*x*x+4*x-9;
    }

    printf("f(%.3f) = %.3f",x,y);
    return 0;
}

