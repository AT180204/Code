#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int m;
    scanf("%d",&m);

    if (m > 0 && m < 4)
    {
        printf("Thang %d thuoc Quy I",m);
    }
    else if (m > 3 && m <7)
    {
        printf("Thang %d thuoc Quy II",m);
    }
    else if (m > 6 && m <10)
    {
        printf("Thang %d thuoc Quy III",m);
    }
    else if (m > 9 && m <13)
    {
        printf("Thang %d thuoc Quy IV",m);
    }
    else
        printf("Trong nam khong co thang %d", m);

    return 0;
}


