#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    unsigned int x, n;
    scanf("%u%u", &x, &n);

    printf("x = %u = 0x%08x\n",x,x);
    printf("x >> %u = %u = 0x%08x\n",n,((x>>n)|(x<<(32-n))),((x>>n)|(x<<(32-n))));
    printf("x << %u = %u = 0x%08x",n,((x<<n)|(x>>(32-n))),((x<<n)|(x>>(32-n))));

    return 0;
}
