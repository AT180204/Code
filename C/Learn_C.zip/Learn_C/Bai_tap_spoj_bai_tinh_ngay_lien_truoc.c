#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int d,m,y;
    int Ngayhientai,Ngayketiep;
    scanf("%d%d%d",&d,&m,&y);

    printf("Ngay hien tai: %d/%d/%d\n",d,m,y);
    d = d - 1;
    if (m == 1 ||m == 3 ||m == 5 ||m == 7 ||m == 8 ||m == 10 ||m == 12 )
    {
        if (d > 0 && d <32)
        {
            Ngayketiep = 1;
        }
        else
        {
            Ngayketiep = 0;
        }
    }
    else if (m == 4 || m == 6 || m == 9 || m == 11)
    {
        if (d > 0 && d < 31)
        {
            Ngayketiep = 1;
        }
        else
        {
            Ngayketiep = 0;
        }
    }
    else if ( m == 2)
    {
        if (y%400==0 || y%4==0 && y%100!=0)
        {
            if (d > 0 && d < 30)
            {
                Ngayketiep = 1;
            }
            else
            {
                Ngayketiep = 0;
            }
        }
        else
        {
            if (d > 0 && d < 29)
            {
                Ngayketiep = 1;
            }
            else
            {
                Ngayketiep = 0;
            }
        }
    }
    else
        Ngayketiep = 0;

    if (Ngayketiep)
    {
        printf("Ngay truoc do: %d/%d/%d",d,m,y);
    }
    else
    {
        if (m == 1 || m == 2 ||m == 4 ||m == 6 ||m == 8 ||m == 9 ||m == 11)
        {
            d = 31;
            m = m-1;
            if (m < 1)
            {
                m = 12;
                y = y-1;
            }
        }
        else if (m == 5 ||m == 7 ||m == 10 ||m == 12)
        {
            d = 30;
            m = m-1;
        }
        else if (m==3)
            if (y%400==0 || y%4==0 && y%100!=0)
            {
                d = 29;
                m = m-1;
            }
            else
            {
                d = 28;
                m = m-1;
            }
        printf("Ngay truoc do: %d/%d/%d",d,m,y);
    }

    return 0;
}



