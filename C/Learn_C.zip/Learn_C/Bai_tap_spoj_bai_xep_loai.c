#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float a,b,c,average;
    scanf("%f%f%f",&a,&b,&c);

    average = 0.1*a+0.2*b+0.7*c;
    if (average >= 9.0)
        printf("%.2f A+",average);
    else if (9.0 > average && average >= 8.5)
        printf("%.2f A",average);
    else if (8.5 > average && average >= 7.8)
        printf("%.2f B+",average);
    else if (7.8 > average && average >= 7.0)
        printf("%.2f B",average);
    else if (7.0 > average && average >= 6.3)
        printf("%.2f C+",average);
    else if (6.3 > average && average >= 5.5)
        printf("%.2f C",average);
    else if (5.5 > average && average >= 4.8)
        printf("%.2f D+",average);
    else if (4.8 > average && average >= 4)
        printf("%.2f D",average);
    else
        printf("%.2f F",average);
    return 0;
}
