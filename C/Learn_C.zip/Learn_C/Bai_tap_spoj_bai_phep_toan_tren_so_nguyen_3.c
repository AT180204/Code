#include <stdio.h>

int main()
{
    int a, b, d1, d2;

    scanf("%d%d", &a, &b);
    scanf("%d%d", &d1, &d2);

    printf("%d : %d = ", a, b);
    printf("%*.*f", d1, d2, (float)a/b);

    return 0;
}
