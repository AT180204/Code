#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    unsigned int a;
    scanf("%u",&a);

    if ((int)(sqrt(a)*10)%10==0)
        printf("Co");
    else
        printf("Khong");
    return 0;
}
