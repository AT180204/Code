#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float a,b,c,max,canhgocvuong1,canhgocvuong2;
    scanf("%f%f%f",&a,&b,&c);

    if (a==b && a==c)
        printf("(%.5f, %.5f, %.5f) la tam giac deu",a,b,c);
    else if ((a==b && a!=c) || (c==b && a!=c) || (a ==c && a!=b))
        printf("(%.5f, %.5f, %.5f) la tam giac can",a,b,c);
    else
    {
        if (a>b)
            if(a>c)
            {
                max = a;
                canhgocvuong1 = b;
                canhgocvuong2 = c;
            }
            else
            {
                max = c;
                canhgocvuong1 = b;
                canhgocvuong2 = a;
            }
        else
            if (b>c)
            {
                max = b;
                canhgocvuong1 = a;
                canhgocvuong2 = c;
            }
            else
            {
                max = c;
                canhgocvuong1 = b;
                canhgocvuong2 = a;
            }
        if (max*max == canhgocvuong1*canhgocvuong1 + canhgocvuong2*canhgocvuong2)
            printf("(%.5f, %.5f, %.5f) la tam giac vuong",a,b,c);
        else
            printf("(%.5f, %.5f, %.5f) la tam giac thuong",a,b,c);
    }
    return 0;
}

