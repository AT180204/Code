#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    unsigned int so1, so2, so3, so4, so5;
    scanf("%u%u%u%u%u",&so1,&so2,&so3,&so4,&so5);

    if (so1%2==1)
        printf("Trong Thuy di duoc 0km va khong duoi kip My Chau");
    else if (so2%2==1)
        printf("Trong Thuy di duoc 10km va khong duoi kip My Chau");
    else if (so3%2==1)
        printf("Trong Thuy di duoc 20km va khong duoi kip My Chau");
    else if (so4%2==1)
        printf("Trong Thuy di duoc 30km va khong duoi kip My Chau");
    else if (so5%2==1)
        printf("Trong Thuy di duoc 40km va khong duoi kip My Chau");
    else
        printf("Trong Thuy di duoc 50km va duoi kip My Chau");
    return 0;
}
