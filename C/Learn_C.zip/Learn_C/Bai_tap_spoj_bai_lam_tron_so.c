#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float x;
    scanf("%f",&x);
    int a = round(x);
    printf("%d",a);
    return 0;
}
