#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    unsigned int x;
    scanf("%u",&x);

    if (x==1)
    {
        printf("Nhom mau: O");
        printf("\nNhan duoc: O");
        printf("\nTruyen duoc: O A B AB");
    }
    if (x==2)
    {
        printf("Nhom mau: A");
        printf("\nNhan duoc: O A");
        printf("\nTruyen duoc: A AB");
    }
    if (x==3)
    {
        printf("Nhom mau: B");
        printf("\nNhan duoc: O B");
        printf("\nTruyen duoc: B AB");
    }
    if (x==4)
    {
        printf("Nhom mau: AB");
        printf("\nNhan duoc: O A B AB");
        printf("\nTruyen duoc: AB");
    }
    return 0;
}
