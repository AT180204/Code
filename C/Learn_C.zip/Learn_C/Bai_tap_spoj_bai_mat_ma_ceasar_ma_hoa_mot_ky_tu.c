#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    char x;
    int key;
    scanf("%c%d",&x,&key);

    x -= 'A';
    x += key;
    x %= 26 ;
    x += 'A';

    printf("%c", x);
    return 0;
}




