#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    unsigned int x;
    scanf("%u",&x);

    printf("x = %08x = %u\n",x,x);
    printf("0: %x = %u\n",(x<<28)>>28,(x<<28)>>28);
    printf("1: %x = %u\n",((x<<24)>>28),((x<<24)>>28));
    printf("2: %x = %u\n",((x<<20)>>28),((x<<20)>>28));
    printf("3: %x = %u\n",((x<<16)>>28),((x<<16)>>28));
    printf("4: %x = %u\n",((x<<12)>>28),((x<<12)>>28));
    printf("5: %x = %u\n",((x<<8)>>28),((x<<8)>>28));
    printf("6: %x = %u\n",((x<<4)>>28),((x<<4)>>28));
    printf("7: %x = %u\n",(x>>28),(x>>28));

    return 0;
}

