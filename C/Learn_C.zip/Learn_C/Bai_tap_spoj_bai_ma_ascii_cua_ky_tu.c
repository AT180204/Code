#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    char x;
    scanf("%c",&x);
    printf("%d",x);
    return 0;
}


