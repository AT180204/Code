#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int xH,yH,xM,yM;
    scanf("%d%d\n%d%d",&xH,&yH,&xM,&yM);

    //xu ly hau an ma
    if ((xH==xM)||(yH==yM)|| (((xH+1)==xM)&&(yH+1)==yM) || (((xH+2)==xM)&&(yH+2)==yM) || (((xH+3)==xM)&&(yH+3)==yM) || (((xH+4)==xM)&&(yH+4)==yM) || (((xH+5)==xM)&&(yH+5)==yM) || (((xH+6)==xM)&&(yH+6)==yM) || (((xH+7)==xM)&&(yH+7)==yM) || (((xH-1)==xM)&&(yH-1)==yM) || (((xH-2)==xM)&&(yH-2)==yM) || (((xH-3)==xM)&&(yH-3)==yM) || (((xH-4)==xM)&&(yH-4)==yM) || (((xH-5)==xM)&&(yH-5)==yM) || (((xH-6)==xM)&&(yH-6)==yM) || (((xH-7)==xM)&&(yH-7)==yM) || (((xH+1)==xM)&&(yH-1)==yM) || (((xH+2)==xM)&&(yH-2)==yM) || (((xH+3)==xM)&&(yH-3)==yM) || (((xH+4)==xM)&&(yH-4)==yM) || (((xH+5)==xM)&&(yH-5)==yM) || (((xH+6)==xM)&&(yH-6)==yM) || (((xH+7)==xM)&&(yH-7)==yM) || (((xH-1)==xM)&&(yH+1)==yM) || (((xH-2)==xM)&&(yH+2)==yM) || (((xH-3)==xM)&&(yH+3)==yM) || (((xH-4)==xM)&&(yH+4)==yM) || (((xH-5)==xM)&&(yH+5)==yM) || (((xH-6)==xM)&&(yH+6)==yM) || (((xH-7)==xM)&&(yH+7)==yM))
        printf("Hau an duoc ma\n");
    else
        printf("Hau khong an duoc ma\n");
    //xu ly ma an hau
    if (((xM+1)==xH)&&((yM-2)==yH)||((xM+2)==xH)&&((yM-1)==yH)||((xM+2)==xH)&&((yM+1)==yH)||((xM+1)==xH)&&((yM+2)==yH)||((xM-1)==xH)&&((yM+2)==yH)||((xM-2)==xH)&&((yM+1)==yH)||((xM-2)==xH)&&((yM-1)==yH)||((xM-1)==xH)&&((yM-2)==yH))
        printf("Ma an duoc hau");
    else
        printf("Ma khong an duoc hau");
    return 0;
}

