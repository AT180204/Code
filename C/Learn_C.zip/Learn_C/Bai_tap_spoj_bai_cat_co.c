#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main ()
{
    unsigned int x1,y1,x2,y2;
    scanf("%u%u\n%u%u",&x1,&y1,&x2,&y2);

    if (x1 <= x2 && y1 <= y2)
        printf("%u",(x2-x1+1)*(y2-y1+1));
    else if (x1 >= x2 && y1 >= y2)
        printf("%u",(-x2+x1+1)*(-y2+y1+1));
    else if (x1 <= x2 && y1 >= y2)
        printf("%u",(x2-x1+1)*(-y2+y1+1));
    else if (x1 >= x2 && y1 <= y2)
        printf("%u",(-x2+x1+1)*(y2-y1+1));

    return 0;
}
