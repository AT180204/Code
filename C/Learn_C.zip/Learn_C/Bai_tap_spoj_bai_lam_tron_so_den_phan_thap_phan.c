#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float x;
    scanf("%f",&x);
    x=round(10*x)/10;
    printf("%.2f",x*x);
    return 0;
}
