#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int y;
    scanf("%d",&y);

    if (y%400==0)
        printf("Nam %d la nam nhuan",y);
    else if (y%4==0 && y%100!=0)
        printf("Nam %d la nam nhuan",y);
    else
        printf("Nam %d khong phai la nam nhuan",y);

    return 0;
}
