#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    char x;
    scanf("%c",&x);
    printf("%c",x +'A'-'a');
    return 0;
}


