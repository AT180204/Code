#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
    int a,b,c;
    scanf("%d%d%d",&a,&b,&c);

    if (a>b)
        if(a>c)
            printf("max{%d, %d, %d} = %d",a,b,c,a);
        else
            printf("max{%d, %d, %d} = %d",a,b,c,c);
    else
        if (b>c)
            printf("max{%d, %d, %d} = %d",a,b,c,b);
        else
            printf("max{%d, %d, %d} = %d",a,b,c,c);
    return 0;
}

